package com.smartscan.studio.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smartscan.studio.ui.components.FeatureCard
import com.smartscan.studio.ui.theme.*
import com.smartscan.studio.viewmodel.StudioViewModel

@Composable
fun HomeScreen(
    viewModel: StudioViewModel,
    onNavigateToNid: () -> Unit,
    onNavigateToDocScanner: () -> Unit,
    onNavigateToPassport: () -> Unit,
    onNavigateToPcTransfer: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToFiles: () -> Unit
) {
    val files by viewModel.files.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(
            start = Spacing.screenHorizontal,
            end = Spacing.screenHorizontal,
            top = Spacing.lg,
            bottom = 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(Spacing.xl)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(Spacing.md)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(EmeraldPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.DocumentScanner,
                            contentDescription = "Logo",
                            tint = Color.White
                        )
                    }
                    Column {
                        Text(
                            text = "Smart Scan & Photo Studio",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Scan. Edit. Save. Share.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(
                    onClick = onNavigateToSettings,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surface)
                ) {
                    Icon(Icons.Outlined.Settings, contentDescription = "Settings")
                }
            }
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = EmeraldPrimary
            ) {
                Row(
                    modifier = Modifier
                        .padding(Spacing.xl)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(Spacing.md)
                    ) {
                        Text(
                            text = "What would you like to create today?",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Button(
                            onClick = onNavigateToDocScanner,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = EmeraldPrimary
                            ),
                            modifier = Modifier.height(48.dp)
                        ) {
                            Icon(Icons.Outlined.CameraAlt, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Start Scanning", fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.width(Spacing.md))
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color.White.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.QrCodeScanner,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(Spacing.md)) {
                Text(
                    text = "Studio Tools",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(Spacing.md)
                ) {
                    FeatureCard(
                        title = "NID Scanner",
                        description = "Front & back on A4 with 0.5\" gap",
                        icon = Icons.Outlined.Badge,
                        accentColor = AccentEmerald,
                        onClick = onNavigateToNid,
                        modifier = Modifier.weight(1f)
                    )
                    FeatureCard(
                        title = "Doc Scanner",
                        description = "Multi-page auto edge PDF scan",
                        icon = Icons.Outlined.Description,
                        accentColor = AccentBlue,
                        onClick = onNavigateToDocScanner,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(Spacing.md)
                ) {
                    FeatureCard(
                        title = "Passport Photo",
                        description = "BG remove & 4x6 print layout",
                        icon = Icons.Outlined.Portrait,
                        accentColor = AccentPurple,
                        onClick = onNavigateToPassport,
                        modifier = Modifier.weight(1f)
                    )
                    FeatureCard(
                        title = "Send to PC",
                        description = "Instant local Wi-Fi QR transfer",
                        icon = Icons.Outlined.Devices,
                        accentColor = AccentOrange,
                        onClick = onNavigateToPcTransfer,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        if (files.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Recent Projects", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    TextButton(onClick = onNavigateToFiles) { Text("View All") }
                }
            }
            items(files.take(3)) { item ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToFiles() },
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Row(
                        modifier = Modifier.padding(Spacing.md),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(Spacing.md)
                    ) {
                        Icon(Icons.Outlined.PictureAsPdf, contentDescription = null, tint = EmeraldPrimary)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text("${item.sizeFormatted} • ${item.dateFormatted}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
