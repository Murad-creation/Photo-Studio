package com.smartscan.studio.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.smartscan.studio.ui.screens.files.MyFilesScreen
import com.smartscan.studio.ui.screens.home.HomeScreen
import com.smartscan.studio.ui.screens.nid.NidScannerScreen
import com.smartscan.studio.ui.screens.passport.PassportStudioScreen
import com.smartscan.studio.ui.screens.scanner.DocumentScannerScreen
import com.smartscan.studio.ui.screens.settings.SettingsScreen
import com.smartscan.studio.ui.screens.transfer.PcTransferScreen
import com.smartscan.studio.viewmodel.StudioViewModel

sealed class Screen(val route: String, val label: String) {
    data object Home : Screen("home", "Home")
    data object MyFiles : Screen("my_files", "My Files")
    data object Settings : Screen("settings", "Settings")
    data object NidScanner : Screen("nid_scanner", "NID Scanner")
    data object DocScanner : Screen("doc_scanner", "Document Scanner")
    data object PassportStudio : Screen("passport_studio", "Passport Studio")
    data object PcTransfer : Screen("pc_transfer", "Send to PC")
}

@Composable
fun SmartScanApp(viewModel: StudioViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val bottomItems = listOf(Screen.Home, Screen.MyFiles, Screen.Settings)
    val showBottomBar = currentRoute in bottomItems.map { it.route }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    bottomItems.forEach { screen ->
                        val selected = currentRoute == screen.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                val icon = when (screen) {
                                    Screen.Home -> if (selected) Icons.Filled.Home else Icons.Outlined.Home
                                    Screen.MyFiles -> if (selected) Icons.Filled.Folder else Icons.Outlined.Folder
                                    Screen.Settings -> if (selected) Icons.Filled.Settings else Icons.Outlined.Settings
                                    else -> Icons.Outlined.Home
                                }
                                Icon(icon, contentDescription = screen.label)
                            },
                            label = { Text(screen.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToNid = { navController.navigate(Screen.NidScanner.route) },
                    onNavigateToDocScanner = { navController.navigate(Screen.DocScanner.route) },
                    onNavigateToPassport = { navController.navigate(Screen.PassportStudio.route) },
                    onNavigateToPcTransfer = { navController.navigate(Screen.PcTransfer.route) },
                    onNavigateToSettings = { navController.navigate(Screen.Settings.route) },
                    onNavigateToFiles = { navController.navigate(Screen.MyFiles.route) }
                )
            }
            composable(Screen.NidScanner.route) {
                NidScannerScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onNavigateToPcTransfer = { navController.navigate(Screen.PcTransfer.route) }
                )
            }
            composable(Screen.DocScanner.route) {
                DocumentScannerScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onNavigateToPcTransfer = { navController.navigate(Screen.PcTransfer.route) }
                )
            }
            composable(Screen.PassportStudio.route) {
                PassportStudioScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.PcTransfer.route) {
                PcTransferScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.MyFiles.route) {
                MyFilesScreen(
                    viewModel = viewModel,
                    onSendToPc = { navController.navigate(Screen.PcTransfer.route) }
                )
            }
            composable(Screen.Settings.route) {
                SettingsScreen(viewModel = viewModel)
            }
        }
    }
}
