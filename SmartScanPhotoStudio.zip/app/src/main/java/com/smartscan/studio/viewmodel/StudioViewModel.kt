package com.smartscan.studio.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartscan.studio.data.*
import com.smartscan.studio.network.LocalTransferServer
import com.smartscan.studio.util.DocumentExportUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class StudioViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = PreferencesRepository(application)
    val transferServer = LocalTransferServer()

    val themeMode: StateFlow<ThemeMode> = prefs.themeModeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeMode.SYSTEM)

    val defaultFilter: StateFlow<String> = prefs.defaultFilterFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Magic Color")

    val defaultPaper: StateFlow<String> = prefs.defaultPaperFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "A4")

    private val _files = MutableStateFlow<List<ScannedDocumentItem>>(emptyList())
    val files: StateFlow<List<ScannedDocumentItem>> = _files.asStateFlow()

    private val _nidState = MutableStateFlow(NidScanState())
    val nidState: StateFlow<NidScanState> = _nidState.asStateFlow()

    private val _scannedPages = MutableStateFlow<List<Bitmap>>(emptyList())
    val scannedPages: StateFlow<List<Bitmap>> = _scannedPages.asStateFlow()

    private val _passportState = MutableStateFlow(PassportStudioState())
    val passportState: StateFlow<PassportStudioState> = _passportState.asStateFlow()

    private val _selectedFileForTransfer = MutableStateFlow<File?>(null)
    val selectedFileForTransfer: StateFlow<File?> = _selectedFileForTransfer.asStateFlow()

    init {
        refreshFiles()
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { prefs.setThemeMode(mode) }
    }

    fun setDefaultFilter(filter: String) {
        viewModelScope.launch { prefs.setDefaultFilter(filter) }
    }

    fun setDefaultPaper(paper: String) {
        viewModelScope.launch { prefs.setDefaultPaper(paper) }
    }

    fun setNidFront(bitmap: Bitmap) {
        _nidState.update { it.copy(frontBitmap = bitmap, step = 2) }
    }

    fun setNidBack(bitmap: Bitmap) {
        _nidState.update { it.copy(backBitmap = bitmap, step = 3) }
    }

    fun updateNidStep(step: Int) {
        _nidState.update { it.copy(step = step) }
    }

    fun exportNidPdf(onExported: (File) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val file = DocumentExportUtils.exportNidToA4Pdf(
                getApplication(),
                _nidState.value.frontBitmap,
                _nidState.value.backBitmap
            )
            _selectedFileForTransfer.value = file
            refreshFiles()
            launch(Dispatchers.Main) { onExported(file) }
        }
    }

    fun addDocumentPage(bitmap: Bitmap) {
        _scannedPages.update { it + bitmap }
    }

    fun removeDocumentPage(index: Int) {
        _scannedPages.update { list -> list.filterIndexed { i, _ -> i != index } }
    }

    fun exportScannedDocumentPdf(fileName: String, onExported: (File) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val pages = _scannedPages.value.ifEmpty { listOf(createSamplePlaceholderBitmap("Scanned Document")) }
            val safeName = if (fileName.endsWith(".pdf")) fileName else "$fileName.pdf"
            val file = DocumentExportUtils.exportBitmapsToPdf(getApplication(), pages, "Scanned_PDFs", safeName)
            _selectedFileForTransfer.value = file
            refreshFiles()
            launch(Dispatchers.Main) { onExported(file) }
        }
    }

    fun updatePassportBg(colorHex: Long) {
        _passportState.update { it.copy(selectedBgHex = colorHex) }
    }

    fun updatePassportSize(size: String) {
        _passportState.update { it.copy(selectedSize = size) }
    }

    fun setPassportPhoto(bitmap: Bitmap) {
        _passportState.update { it.copy(sourceBitmap = bitmap) }
    }

    fun selectFileForTransfer(file: File) {
        _selectedFileForTransfer.value = file
    }

    fun deleteFile(item: ScannedDocumentItem) {
        viewModelScope.launch(Dispatchers.IO) {
            if (item.file.exists()) item.file.delete()
            refreshFiles()
        }
    }

    fun renameFile(item: ScannedDocumentItem, newName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val target = File(item.file.parentFile, newName)
            if (item.file.renameTo(target)) refreshFiles()
        }
    }

    fun refreshFiles() {
        viewModelScope.launch(Dispatchers.IO) {
            val root = getApplication<Application>().filesDir
            val allItems = mutableListOf<ScannedDocumentItem>()
            val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

            root.walkTopDown().filter { it.isFile && (it.extension == "pdf" || it.extension == "jpg" || it.extension == "png") }.forEach { f ->
                val cat = when {
                    f.parentFile?.name?.contains("NID") == true -> FileCategory.NID
                    f.parentFile?.name?.contains("Passport") == true -> FileCategory.PASSPORT
                    else -> FileCategory.PDF
                }
                val kb = (f.length() / 1024).coerceAtLeast(1)
                allItems.add(
                    ScannedDocumentItem(
                        id = f.absolutePath,
                        name = f.name,
                        category = cat,
                        file = f,
                        sizeFormatted = "$kb KB",
                        dateFormatted = dateFormat.format(Date(f.lastModified()))
                    )
                )
            }
            _files.value = allItems.sortedByDescending { it.file.lastModified() }
        }
    }

    fun createSamplePlaceholderBitmap(label: String): Bitmap {
        val bmp = Bitmap.createBitmap(800, 500, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.parseColor("#F5F8F6"))
        val paint = Paint().apply {
            color = Color.parseColor("#087C43")
            textSize = 42f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(label, 400f, 260f, paint)
        return bmp
    }

    override fun onCleared() {
        super.onCleared()
        transferServer.stopServer()
    }
}
