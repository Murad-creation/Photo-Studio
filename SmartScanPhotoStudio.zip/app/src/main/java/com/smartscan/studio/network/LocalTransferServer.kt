package com.smartscan.studio.network

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.*
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.util.UUID

class LocalTransferServer {
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    val sessionToken: String = UUID.randomUUID().toString().take(6).uppercase()

    fun getLocalIpAddress(): String? {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val intf = interfaces.nextElement()
                val addrs = intf.inetAddresses
                while (addrs.hasMoreElements()) {
                    val addr = addrs.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress
                    }
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    fun startServer(
        fileToShare: File,
        port: Int = 8080,
        onClientConnected: (String) -> Unit,
        onTransferComplete: () -> Unit,
        onError: (String) -> Unit
    ): String? {
        val ip = getLocalIpAddress()
        if (ip == null) {
            onError("Wi-Fi not connected. Connect phone and PC to the same Wi-Fi network.")
            return null
        }
        stopServer()

        serverJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                serverSocket = ServerSocket(port)
                while (isActive) {
                    val client = serverSocket?.accept() ?: break
                    val clientIp = client.inetAddress.hostAddress ?: "Connected PC"
                    withContext(Dispatchers.Main) { onClientConnected(clientIp) }

                    val reader = client.getInputStream().bufferedReader()
                    val requestLine = reader.readLine() ?: ""
                    val out = client.getOutputStream()

                    if (requestLine.contains("/download?token=$sessionToken") && fileToShare.exists()) {
                        val fileBytes = fileToShare.readBytes()
                        val header = "HTTP/1.1 200 OK\r\n" +
                            "Content-Type: application/octet-stream\r\n" +
                            "Content-Disposition: attachment; filename=\"${fileToShare.name}\"\r\n" +
                            "Content-Length: ${fileBytes.size}\r\n" +
                            "Connection: close\r\n\r\n"

                        out.write(header.toByteArray())
                        out.write(fileBytes)
                        out.flush()
                        withContext(Dispatchers.Main) { onTransferComplete() }
                    } else {
                        val html = """
                            <!DOCTYPE html>
                            <html>
                            <head><title>Smart Scan & Photo Studio</title></head>
                            <body style="font-family:sans-serif;background:#F5F8F6;text-align:center;padding:50px;">
                                <div style="max-width:420px;margin:auto;background:#fff;padding:32px;border-radius:18px;box-shadow:0 4px 16px rgba(0,0,0,0.08);">
                                    <h2 style="color:#087C43;margin-bottom:8px;">Smart Scan & Photo Studio</h2>
                                    <p style="color:#4A5D54;">File ready for transfer:</p>
                                    <p style="font-weight:bold;color:#172820;">${fileToShare.name}</p>
                                    <a href="/download?token=$sessionToken" 
                                       style="display:inline-block;margin-top:20px;background:#087C43;color:#fff;padding:14px 28px;text-decoration:none;border-radius:12px;font-weight:bold;">
                                       Download to PC
                                    </a>
                                </div>
                            </body>
                            </html>
                        """.trimIndent()
                        val response = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Length: ${html.toByteArray().size}\r\nConnection: close\r\n\r\n$html"
                        out.write(response.toByteArray())
                        out.flush()
                    }
                    client.close()
                }
            } catch (e: Exception) {
                if (isActive) {
                    withContext(Dispatchers.Main) { onError(e.message ?: "Server stopped") }
                }
            }
        }
        return "http://$ip:$port/?token=$sessionToken"
    }

    fun stopServer() {
        serverJob?.cancel()
        try {
            serverSocket?.close()
        } catch (_: Exception) { }
        serverSocket = null
    }

    companion object {
        fun generateQrBitmap(content: String, size: Int = 512): Bitmap? {
            return try {
                val bitMatrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size)
                val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
                for (x in 0 until size) {
                    for (y in 0 until size) {
                        bitmap.setPixel(x, y, if (bitMatrix[x, y]) Color.BLACK else Color.WHITE)
                    }
                }
                bitmap
            } catch (_: Exception) {
                null
            }
        }
    }
}
