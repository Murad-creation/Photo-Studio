package com.smartscan.studio.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "smart_scan_settings")

class PreferencesRepository(private val context: Context) {
    private val THEME_KEY = stringPreferencesKey("theme_mode")
    private val DEFAULT_FILTER_KEY = stringPreferencesKey("default_filter")
    private val DEFAULT_PAPER_KEY = stringPreferencesKey("default_paper")
    private val DEFAULT_EXPORT_FORMAT_KEY = stringPreferencesKey("default_export_format")
    private val DEFAULT_DPI_KEY = stringPreferencesKey("default_dpi")

    val themeModeFlow: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        when (prefs[THEME_KEY]) {
            ThemeMode.LIGHT.name -> ThemeMode.LIGHT
            ThemeMode.DARK.name -> ThemeMode.DARK
            else -> ThemeMode.SYSTEM
        }
    }

    val defaultFilterFlow: Flow<String> = context.dataStore.data.map { it[DEFAULT_FILTER_KEY] ?: "Magic Color" }
    val defaultPaperFlow: Flow<String> = context.dataStore.data.map { it[DEFAULT_PAPER_KEY] ?: "A4" }
    val defaultExportFormatFlow: Flow<String> = context.dataStore.data.map { it[DEFAULT_EXPORT_FORMAT_KEY] ?: "PDF" }
    val defaultDpiFlow: Flow<String> = context.dataStore.data.map { it[DEFAULT_DPI_KEY] ?: "300 DPI" }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[THEME_KEY] = mode.name }
    }

    suspend fun setDefaultFilter(filter: String) {
        context.dataStore.edit { it[DEFAULT_FILTER_KEY] = filter }
    }

    suspend fun setDefaultPaper(paper: String) {
        context.dataStore.edit { it[DEFAULT_PAPER_KEY] = paper }
    }

    suspend fun setDefaultExportFormat(format: String) {
        context.dataStore.edit { it[DEFAULT_EXPORT_FORMAT_KEY] = format }
    }

    suspend fun setDefaultDpi(dpi: String) {
        context.dataStore.edit { it[DEFAULT_DPI_KEY] = dpi }
    }
}
