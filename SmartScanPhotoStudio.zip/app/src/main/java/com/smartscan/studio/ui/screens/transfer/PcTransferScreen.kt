package com.smartscan.studio.ui.screens.transfer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smartscan.studio.network.LocalTransferServer
import com.smartscan.studio.ui.components.PrimaryActionButton
import com.smartscan.studio.ui.components.SmartScanTopBar
import com.smartscan.studio.ui.theme.Spacing
import com.smartscan.studio.viewmodel.StudioViewModel

@Composable
fun PcTransferScreen(
    viewModel: StudioViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val files by viewModel.files.collectAsState()
    val selectedFile by viewModel.selectedFileForTransfer.collectAsState()
    val targetFile = selectedFile ?: files.firstOrNull()?.file

    var serverUrl by remember { mutableStateOf<String?>(null) }
    var qrBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var statusText by remember { mutableStateOf("Server Stopped") }
    var connectedClient by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            viewModel.transferServer.stopServer()
        }
    }

    Scaffold(
        topBar = { SmartScanTopBar(title = "Send to PC (Wi-Fi)", onBack = onBack) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = Spacing.screenHorizontal),
            verticalArrangement = Arrangement.spacedBy(Spacing.lg),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier.padding(Spacing.lg),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Outlined.Wifi, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(statusText, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = "Selected File: ${targetFile?.name ?: "No file generated yet"}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (connectedClient != null) {
                        Text(
                            text = "Connected Device: $connectedClient",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            if (qrBitmap != null && serverUrl != null) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.White,
                    tonalElevation = 2.dp
                ) {
                    Column(
                        modifier = Modifier.padding(Spacing.xl),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(Spacing.md)
                    ) {
                        Image(
                            bitmap = qrBitmap!!.asImageBitmap(),
                            contentDescription = "Transfer QR Code",
                            modifier = Modifier.size(210.dp)
                        )
                        Text(
                            text = serverUrl!!,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.Black
                        )
                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Transfer URL", serverUrl))
                                Toast.makeText(context, "URL Copied", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Outlined.ContentCopy, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Copy URL")
                        }
                    }
                }
            }

            Spacer(Modifier.weight(1f))

            if (serverUrl == null) {
                PrimaryActionButton(
                    text = "Start Transfer Server & Generate QR",
                    icon = Icons.Outlined.QrCode2,
                    enabled = targetFile != null,
                    onClick = {
                        targetFile?.let { file ->
                            val url = viewModel.transferServer.startServer(
                                fileToShare = file,
                                onClientConnected = { client ->
                                    connectedClient = client
                                    statusText = "PC Connected"
                                },
                                onTransferComplete = {
                                    statusText = "Download Completed!"
                                },
                                onError = { err ->
                                    statusText = err
                                }
                            )
                            if (url != null) {
                                serverUrl = url
                                qrBitmap = LocalTransferServer.generateQrBitmap(url)
                                statusText = "Server Active • Scan QR on PC"
                            }
                        }
                    }
                )
            } else {
                Button(
                    onClick = {
                        viewModel.transferServer.stopServer()
                        serverUrl = null
                        qrBitmap = null
                        connectedClient = null
                        statusText = "Server Stopped"
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Outlined.StopCircle, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Stop Server")
                }
            }
            Spacer(Modifier.height(Spacing.lg))
        }
    }
}
