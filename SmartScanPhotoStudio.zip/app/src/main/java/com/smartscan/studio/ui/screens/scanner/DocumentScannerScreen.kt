package com.smartscan.studio.ui.screens.scanner

import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smartscan.studio.ui.components.EmptyStateView
import com.smartscan.studio.ui.components.PrimaryActionButton
import com.smartscan.studio.ui.components.SmartScanTopBar
import com.smartscan.studio.ui.theme.Spacing
import com.smartscan.studio.viewmodel.StudioViewModel

@Composable
fun DocumentScannerScreen(
    viewModel: StudioViewModel,
    onBack: () -> Unit,
    onNavigateToPcTransfer: () -> Unit
) {
    val context = LocalContext.current
    val pages by viewModel.scannedPages.collectAsState()
    var selectedPaper by remember { mutableStateOf("A4") }
    var selectedFilter by remember { mutableStateOf("Magic Color") }
    var docName by remember { mutableStateOf("Document_${System.currentTimeMillis() / 1000}") }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        uris.forEach { uri ->
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream)?.let { bmp ->
                    viewModel.addDocumentPage(bmp)
                }
            }
        }
    }

    Scaffold(
        topBar = { SmartScanTopBar(title = "Document Scanner", onBack = onBack) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = Spacing.screenHorizontal),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(Spacing.md)) {
                OutlinedTextField(
                    value = docName,
                    onValueChange = { docName = it },
                    label = { Text("Document Name") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )

                Text("Paper Size", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                    itemsIndexed(listOf("A4", "A3", "A5", "Letter", "Legal")) { _, size ->
                        FilterChip(
                            selected = selectedPaper == size,
                            onClick = { selectedPaper = size },
                            label = { Text(size) }
                        )
                    }
                }

                Text("Enhancement Filter", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                    itemsIndexed(listOf("Original", "Magic Color", "Grayscale", "Black & White")) { _, filter ->
                        FilterChip(
                            selected = selectedFilter == filter,
                            onClick = { selectedFilter = filter },
                            label = { Text(filter) }
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = Spacing.md),
                contentAlignment = Alignment.Center
            ) {
                if (pages.isEmpty()) {
                    EmptyStateView(
                        icon = Icons.Outlined.DocumentScanner,
                        title = "No Pages Added",
                        subtitle = "Import images from gallery or add a scan page",
                        actionLabel = "Add Pages",
                        onAction = { imagePicker.launch("image/*") }
                    )
                } else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(Spacing.md)) {
                        itemsIndexed(pages) { index, bmp ->
                            Surface(
                                modifier = Modifier
                                    .width(200.dp)
                                    .fillMaxHeight(0.85f),
                                shape = RoundedCornerShape(16.dp),
                                tonalElevation = 2.dp
                            ) {
                                Box {
                                    Image(
                                        bitmap = bmp.asImageBitmap(),
                                        contentDescription = "Page ${index + 1}",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    IconButton(
                                        onClick = { viewModel.removeDocumentPage(index) },
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(6.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.85f))
                                    ) {
                                        Icon(Icons.Outlined.Delete, contentDescription = "Delete Page")
                                    }
                                    Surface(
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(8.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            "Page ${index + 1}",
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.padding(bottom = Spacing.lg),
                verticalArrangement = Arrangement.spacedBy(Spacing.sm)
            ) {
                OutlinedButton(
                    onClick = { imagePicker.launch("image/*") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Outlined.AddPhotoAlternate, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Add More Pages (${pages.size})")
                }
                PrimaryActionButton(
                    text = "Export Multi-Page PDF",
                    icon = Icons.Outlined.PictureAsPdf,
                    onClick = {
                        viewModel.exportScannedDocumentPdf(docName) { file ->
                            Toast.makeText(context, "Saved ${file.name}", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }
        }
    }
}
