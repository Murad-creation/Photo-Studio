package com.smartscan.studio.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldContainerLight,
    onPrimaryContainer = PrimaryTextLight,
    secondary = EmeraldSecondary,
    onSecondary = Color.White,
    background = LightBackground,
    onBackground = PrimaryTextLight,
    surface = LightSurface,
    onSurface = PrimaryTextLight,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = SecondaryTextLight,
    error = ErrorRed
)

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldSecondary,
    onPrimary = DarkBackground,
    primaryContainer = EmeraldContainerDark,
    onPrimaryContainer = PrimaryTextDark,
    secondary = EmeraldPrimary,
    onSecondary = Color.White,
    background = DarkBackground,
    onBackground = PrimaryTextDark,
    surface = DarkSurface,
    onSurface = PrimaryTextDark,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = SecondaryTextDark,
    error = Color(0xFFF28B82)
)

@Composable
fun SmartScanTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        shapes = AppShapes,
        content = content
    )
}
