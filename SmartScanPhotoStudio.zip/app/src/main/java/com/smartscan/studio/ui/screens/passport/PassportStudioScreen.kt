package com.smartscan.studio.ui.screens.passport

import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smartscan.studio.ui.components.PrimaryActionButton
import com.smartscan.studio.ui.components.SmartScanTopBar
import com.smartscan.studio.ui.theme.Spacing
import com.smartscan.studio.viewmodel.StudioViewModel

@Composable
fun PassportStudioScreen(
    viewModel: StudioViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val state by viewModel.passportState.collectAsState()

    val palette = listOf(
        "White" to 0xFFFFFFFF,
        "Light Blue" to 0xFFD6EAF8,
        "Sky Blue" to 0xFF5DADE2,
        "Pro Blue" to 0xFF1F618D,
        "Dark Blue" to 0xFF154360
    )
    val sizes = listOf("35 × 45 mm", "2 × 2 inch", "4 × 6 inch", "Custom")

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            context.contentResolver.openInputStream(it)?.use { stream ->
                BitmapFactory.decodeStream(stream)?.let { bmp -> viewModel.setPassportPhoto(bmp) }
            }
        }
    }

    Scaffold(
        topBar = {
            SmartScanTopBar(
                title = "Passport Photo Studio",
                onBack = onBack,
                actions = {
                    IconButton(onClick = { picker.launch("image/*") }) {
                        Icon(Icons.Outlined.PhotoLibrary, contentDescription = "Select Photo")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = Spacing.screenHorizontal),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = Spacing.md),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .aspectRatio(35f / 45f)
                        .fillMaxHeight(0.85f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(state.selectedBgHex))
                        .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    val photo = state.sourceBitmap
                    if (photo != null) {
                        Image(
                            bitmap = photo.asImageBitmap(),
                            contentDescription = "Passport Portrait",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Outlined.Portrait, contentDescription = null, modifier = Modifier.size(64.dp), tint = Color.DarkGray)
                            Text("Tap gallery icon to import", style = MaterialTheme.typography.labelMedium, color = Color.DarkGray)
                        }
                    }
                }
            }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = Spacing.lg),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier.padding(Spacing.lg),
                    verticalArrangement = Arrangement.spacedBy(Spacing.md)
                ) {
                    Text("Background Color", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(Spacing.md)) {
                        items(palette) { (_, hex) ->
                            val selected = state.selectedBgHex == hex
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(Color(hex))
                                    .border(
                                        width = if (selected) 3.dp else 1.dp,
                                        color = if (selected) MaterialTheme.colorScheme.primary else Color.Gray,
                                        shape = CircleShape
                                    )
                                    .clickable { viewModel.updatePassportBg(hex) }
                            )
                        }
                    }

                    Text("Photo Size Presets", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
                        items(sizes) { size ->
                            FilterChip(
                                selected = state.selectedSize == size,
                                onClick = { viewModel.updatePassportSize(size) },
                                label = { Text(size) }
                            )
                        }
                    }

                    PrimaryActionButton(
                        text = "Export Print Sheet (4×6 / A4)",
                        icon = Icons.Outlined.SaveAlt,
                        onClick = {
                            Toast.makeText(context, "Passport Sheet Ready (${state.selectedSize})", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}
