package com.smartscan.studio.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF087C43)
val EmeraldSecondary = Color(0xFF12A866)
val EmeraldContainerLight = Color(0xFFD8F3E5)
val EmeraldContainerDark = Color(0xFF064E2B)

val LightBackground = Color(0xFFF5F8F6)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE8EFEA)
val PrimaryTextLight = Color(0xFF172820)
val SecondaryTextLight = Color(0xFF4A5D54)

val DarkBackground = Color(0xFF101A15)
val DarkSurface = Color(0xFF19251E)
val DarkSurfaceVariant = Color(0xFF23332A)
val PrimaryTextDark = Color(0xFFF2F7F3)
val SecondaryTextDark = Color(0xFFA3B5AC)

val AccentBlue = Color(0xFF1E6FD9)
val AccentPurple = Color(0xFF7B42F6)
val AccentOrange = Color(0xFFE66A1F)
val AccentEmerald = Color(0xFF087C43)

val ErrorRed = Color(0xFFD93025)
val SuccessGreen = Color(0xFF0F9D58)
