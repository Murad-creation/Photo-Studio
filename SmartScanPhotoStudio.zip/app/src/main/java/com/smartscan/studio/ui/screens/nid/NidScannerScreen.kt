package com.smartscan.studio.ui.screens.nid

import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smartscan.studio.ui.components.PrimaryActionButton
import com.smartscan.studio.ui.components.SmartScanTopBar
import com.smartscan.studio.ui.theme.Spacing
import com.smartscan.studio.viewmodel.StudioViewModel

@Composable
fun NidScannerScreen(
    viewModel: StudioViewModel,
    onBack: () -> Unit,
    onNavigateToPcTransfer: () -> Unit
) {
    val context = LocalContext.current
    val nidState by viewModel.nidState.collectAsState()
    var capturingFront by remember { mutableStateOf(true) }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            context.contentResolver.openInputStream(it)?.use { stream ->
                val bmp = BitmapFactory.decodeStream(stream)
                if (bmp != null) {
                    if (capturingFront) viewModel.setNidFront(bmp) else viewModel.setNidBack(bmp)
                }
            }
        }
    }

    Scaffold(
        topBar = { SmartScanTopBar(title = "NID Scanner (A4 Layout)", onBack = onBack) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = Spacing.screenHorizontal),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Capture Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(Spacing.sm)
            ) {
                OutlinedButton(
                    onClick = {
                        capturingFront = true
                        galleryLauncher.launch("image/*")
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Outlined.PhotoLibrary, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Import Front")
                }
                OutlinedButton(
                    onClick = {
                        capturingFront = false
                        galleryLauncher.launch("image/*")
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Outlined.PhotoLibrary, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Import Back")
                }
            }

            // A4 Portrait Preview Canvas (210mm x 297mm) with exact 0.5 inch gap
            Box(
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = Spacing.md)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                BoxWithConstraints(
                    modifier = Modifier
                        .aspectRatio(210f / 297f)
                        .fillMaxHeight()
                        .shadow(6.dp, RoundedCornerShape(4.dp))
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    val halfInchGap = maxHeight * (0.5f / 11.69f)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.68f)
                                .aspectRatio(85.6f / 53.98f)
                                .border(1.dp, Color.LightGray, RoundedCornerShape(6.dp))
                                .background(Color(0xFFF8FAF9)),
                            contentAlignment = Alignment.Center
                        ) {
                            val front = nidState.frontBitmap
                            if (front != null) {
                                Image(
                                    bitmap = front.asImageBitmap(),
                                    contentDescription = "Front NID",
                                    contentScale = ContentScale.FillBounds,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Text("FRONT SIDE", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            }
                        }

                        Spacer(modifier = Modifier.height(halfInchGap))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.68f)
                                .aspectRatio(85.6f / 53.98f)
                                .border(1.dp, Color.LightGray, RoundedCornerShape(6.dp))
                                .background(Color(0xFFF8FAF9)),
                            contentAlignment = Alignment.Center
                        ) {
                            val back = nidState.backBitmap
                            if (back != null) {
                                Image(
                                    bitmap = back.asImageBitmap(),
                                    contentDescription = "Back NID",
                                    contentScale = ContentScale.FillBounds,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Text("BACK SIDE", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            }
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.padding(bottom = Spacing.lg),
                verticalArrangement = Arrangement.spacedBy(Spacing.sm)
            ) {
                PrimaryActionButton(
                    text = "Export A4 PDF (0.5\" Gap)",
                    icon = Icons.Outlined.PictureAsPdf,
                    onClick = {
                        viewModel.exportNidPdf { file ->
                            Toast.makeText(context, "Saved: ${file.name}", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
                OutlinedButton(
                    onClick = {
                        viewModel.exportNidPdf {
                            onNavigateToPcTransfer()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Outlined.Devices, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Export & Send to PC")
                }
            }
        }
    }
}
