package com.smartscan.studio.util

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream

object DocumentExportUtils {

    fun applyImageFilter(source: Bitmap, filter: String, brightness: Float, contrast: Float): Bitmap {
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint()

        val colorMatrix = ColorMatrix()
        when (filter) {
            "Grayscale" -> colorMatrix.setSaturation(0f)
            "Black & White" -> {
                colorMatrix.setSaturation(0f)
                val bw = ColorMatrix(
                    floatArrayOf(
                        2f, 0f, 0f, 0f, -128f,
                        0f, 2f, 0f, 0f, -128f,
                        0f, 0f, 2f, 0f, -128f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                colorMatrix.postConcat(bw)
            }
            "Magic Color", "Auto Enhance" -> {
                colorMatrix.setSaturation(1.25f)
            }
        }

        val scale = contrast
        val translate = brightness * 255f
        val bcMatrix = ColorMatrix(
            floatArrayOf(
                scale, 0f, 0f, 0f, translate,
                0f, scale, 0f, 0f, translate,
                0f, 0f, scale, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
        colorMatrix.postConcat(bcMatrix)
        paint.colorFilter = ColorMatrixColorFilter(colorMatrix)
        canvas.drawBitmap(source, 0f, 0f, paint)
        return result
    }

    /**
     * Generates an A4 PDF (595 x 842 pt at 72 DPI) with Front NID card on top,
     * Back NID card below, and an exact 0.5 inch (36 pt) vertical gap between them.
     */
    fun exportNidToA4Pdf(
        context: Context,
        frontBitmap: Bitmap?,
        backBitmap: Bitmap?,
        fileName: String = "NID_A4_${System.currentTimeMillis()}.pdf"
    ): File {
        val pdfDocument = PdfDocument()
        // A4 at 72 DPI: 8.27 in x 11.69 in -> 595 x 842 points
        val pageWidth = 595
        val pageHeight = 842
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas
        canvas.drawColor(Color.WHITE)

        // Standard NID size: 85.6mm x 53.98mm -> 3.37 in x 2.125 in -> 243 pt x 153 pt
        val cardWidth = 243f
        val cardHeight = 153f
        // Exact 0.5 inch gap = 36 points at 72 DPI
        val halfInchGap = 36f

        val totalBlockHeight = (cardHeight * 2) + halfInchGap
        val startX = (pageWidth - cardWidth) / 2f
        val startY = (pageHeight - totalBlockHeight) / 2f

        val frontRect = RectF(startX, startY, startX + cardWidth, startY + cardHeight)
        val backRect = RectF(startX, startY + cardHeight + halfInchGap, startX + cardWidth, startY + (cardHeight * 2) + halfInchGap)

        val borderPaint = Paint().apply {
            style = Paint.Style.STROKE
            color = Color.LTGRAY
            strokeWidth = 1f
        }

        if (frontBitmap != null) {
            canvas.drawBitmap(frontBitmap, null, frontRect, null)
        } else {
            canvas.drawRect(frontRect, borderPaint)
        }

        if (backBitmap != null) {
            canvas.drawBitmap(backBitmap, null, backRect, null)
        } else {
            canvas.drawRect(backRect, borderPaint)
        }

        pdfDocument.finishPage(page)
        val dir = File(context.filesDir, "NID_Documents").apply { mkdirs() }
        val outputFile = File(dir, fileName)
        FileOutputStream(outputFile).use { pdfDocument.writeTo(it) }
        pdfDocument.close()
        return outputFile
    }

    fun exportBitmapsToPdf(
        context: Context,
        pages: List<Bitmap>,
        folderName: String = "Scanned_PDFs",
        fileName: String = "Scan_${System.currentTimeMillis()}.pdf"
    ): File {
        val pdfDocument = PdfDocument()
        pages.forEachIndexed { index, bmp ->
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, index + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            page.canvas.drawColor(Color.WHITE)
            val dest = RectF(24f, 24f, 571f, 818f)
            page.canvas.drawBitmap(bmp, null, dest, null)
            pdfDocument.finishPage(page)
        }
        val dir = File(context.filesDir, folderName).apply { mkdirs() }
        val outputFile = File(dir, fileName)
        FileOutputStream(outputFile).use { pdfDocument.writeTo(it) }
        pdfDocument.close()
        return outputFile
    }
}
