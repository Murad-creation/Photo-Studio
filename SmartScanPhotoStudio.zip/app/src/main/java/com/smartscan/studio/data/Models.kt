package com.smartscan.studio.data

import android.graphics.Bitmap
import java.io.File

enum class ThemeMode(val label: String) {
    LIGHT("Light Mode"),
    DARK("Dark Mode"),
    SYSTEM("System Default")
}

enum class FileCategory(val label: String) {
    ALL("All Files"),
    NID("NID Documents"),
    PDF("Scanned PDFs"),
    PASSPORT("Passport Photos"),
    FAVORITES("Favorites")
}

data class ScannedDocumentItem(
    val id: String,
    val name: String,
    val category: FileCategory,
    val file: File,
    val sizeFormatted: String,
    val dateFormatted: String,
    val isFavorite: Boolean = false
)

data class NidScanState(
    val step: Int = 1,
    val frontBitmap: Bitmap? = null,
    val backBitmap: Bitmap? = null,
    val selectedFilter: String = "Original",
    val brightness: Float = 0f,
    val contrast: Float = 1f
)

data class PassportStudioState(
    val sourceBitmap: Bitmap? = null,
    val selectedBgHex: Long = 0xFFD6EAF8,
    val selectedSize: String = "35 × 45 mm",
    val printSheetSize: String = "4 × 6 inch",
    val copiesCount: Int = 6,
    val brightness: Float = 0f,
    val contrast: Float = 1f
)
