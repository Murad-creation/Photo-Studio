# Keep ZXing and CameraX classes
-keep class com.google.zxing.** { *; }
