# Smart Scan & Photo Studio

**Tagline:** Scan. Edit. Save. Share.

A modern Android application built with **Kotlin**, **Jetpack Compose**, and **Material 3**, featuring an Emerald Green (`#087C43`) design system with full Light & Dark mode support.

## Features
- **Home Dashboard**: Quick access to all studio modules, storage status, and recent files.
- **NID Scanner**: 5-step workflow with Front & Back capture, image enhancement, and A4 print layout with an exact `0.5 inch` gap.
- **Document Scanner**: Multi-page scanning, filter adjustments, paper size selection (A4, A3, A5, Letter, Legal), and PDF export.
- **Passport Photo Studio**: Background replacement palette, preset dimensions (`35x45 mm`, `2x2 inch`, `4x6 inch`), and print sheet arrangement.
- **Send to PC**: Real local Wi-Fi HTTP server with dynamic QR code and token authentication for instant PC downloads.
- **My Files & Settings**: File management, search/filter, and persistent theme preferences via DataStore.

## GitHub Actions APK Build
Push this repository to GitHub (`main` or `master` branch) and open the **Actions** tab to download the compiled `SmartScan-PhotoStudio-Debug-APK`.
