# Smart Scan & Photo Studio (Phase 1)

Scan. Edit. Save. Share.

Phase 1 delivers: design system (Color/Theme/Type/Shape/Spacing/ComponentStyles), Light/Dark/System theme
persisted with DataStore, Navigation Compose with bottom navigation and saved/restored tab state, and the Home dashboard.

NID Scanner, Document Scanner, Passport Photo Studio and Send to PC currently open a clearly labelled
"Not built yet" screen. They are the next phases. Recent Projects / Recently Scanned show empty states
until real data exists. The storage card reads real device storage.

Build: push to GitHub (Actions builds the debug APK) or run `gradle assembleDebug` with Gradle 8.9 and JDK 17.
